import React from 'react'
import Header from '../../AllPagesComponents/Header/Header'

function ItemManagement() {
  return (
    <>
      <Header title='Item Management' />
      <div className="main_body">
         <div className="body_header">
            <p>Dashboard/item</p>
         </div>
         
      </div>
    </>
  )
}

export default ItemManagement