import React from 'react'

function User({children}) {
  return (
    <div className='user_wrapper'>{children}</div>
  )
}

export default User