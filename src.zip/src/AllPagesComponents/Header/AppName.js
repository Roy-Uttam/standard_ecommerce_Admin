import React from 'react'

function AppName({children}) {
  return (
    <h1 className="app_name">{children}</h1>
  )
}

export default AppName